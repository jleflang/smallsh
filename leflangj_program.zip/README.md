# Smallsh: A Small Shell
Portfolio Project for Oregon State University's CS344: Operating Systems I

## To compile:
`gcc --std=gnu99 -g -o smallsh smallsh.c`

## About this project:
This educational project is to write a small shell that can handle `cd`,
`status`, and `exit` internally.
All other commands are run externally as forked processes.

